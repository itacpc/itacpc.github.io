#!/usr/bin/env python3
# @check-time-limit-exceeded: task

from dataclasses import dataclass
from collections import deque

@dataclass
class Point:
    x: int
    y: int

n = int(input())
A = [int(i) for i in input().split()]
tot = sum(A)

Psum = [0 for _ in range(n+1)]
deques = [deque() for _ in range(n+1)]

deques[0].append(Point(0,0))

ans = tot
for i in range(1,n+1):
    x_i = Psum[i-1] + A[i-1]
    Psum[i] = x_i
    for j in range(i):
        visit = False
        while len(deques[j])>0 and (deques[j][0].x + Psum[j] < x_i):
            best = deques[j].popleft()
            visit = True
        if visit:
            deques[j].appendleft(best)
            while len(deques[i])>0 and (deques[i][-1].x > best.y):
                deques[i].pop()
            deques[i].append(Point(best.y,x_i-Psum[j]))
            if i == n:
                ans = min(ans,(best.y+x_i-Psum[j]))


print(ans)
