// @check-time-limit-exceeded: task

#include <iostream>
#include <vector>
#include <array>

using namespace std;

typedef unsigned long long int ull;

#define maxr(a, b) (a) = max((a), (b));
#define minr(a, b) (a) = min((a), (b));

#define k 3

struct node_t
{
    array<size_t, k> point = {{0, 0, 0}};
    node_t *l = nullptr;
    node_t *r = nullptr;

    bool IsLessThanOrEqual(const array<size_t, k> &b)
    {
        for (size_t i = 0; i < k; ++i)
            if (point[i] > b[i])
                return false;

        return true;
    }
};

node_t *new_node(array<size_t, k> point)
{
    node_t *node = new node_t;
    node->point = std::move(point);
    node->l = nullptr;
    node->r = nullptr;
    return node;
};

node_t *insert_helper(node_t *root, const array<size_t, k> &point, size_t depth)
{
    if (root == nullptr)
        return new_node(point);

    size_t i = depth % k;

    if (point[i] < (root->point[i]))
        root->l = insert_helper(root->l, point, depth + 1);
    else
        root->r = insert_helper(root->r, point, depth + 1);

    return root;
}

node_t *insert(node_t *root, const array<size_t, k> &point)
{
    return insert_helper(root, point, 0);
}

static size_t max_coord = 2;
// left bounded
node_t *three_sided_tange_max_helper(node_t *root, const array<size_t, k> &point, size_t depth)
{
    // cerr << "in depth: " << depth << endl;
    if (root == nullptr)
        return root;

    size_t i = depth % k;

    node_t *res = three_sided_tange_max_helper(root->l, point, depth + 1);
    if (point[i] >= root->point[i])
    {
        node_t *right = three_sided_tange_max_helper(root->r, point, depth + 1);
        // cerr << "depth: " << depth << " right: " << (right != nullptr);
        // if(right != nullptr) cerr << " cond: " << (right->IsLessThanOrEqual(point) && (res == nullptr || res->point[max_coord] < right->point[max_coord])) << endl;
        // else cerr << endl;
        if (right != nullptr && right->IsLessThanOrEqual(point) && (res == nullptr || res->point[max_coord] < right->point[max_coord]))
            res = right;
    }
    // cerr << "depth: " << depth << " root lte: " << root->IsLessThanOrEqual(point) << " cond: " << (root->IsLessThanOrEqual(point) && (res == nullptr || res->point[max_coord] < root->point[max_coord])) << endl;
    if (root->IsLessThanOrEqual(point) && (res == nullptr || res->point[max_coord] < root->point[max_coord]))
        return root;
    else
        return res;
}

int main(int argc, char const *argv[])
{

    // Read Input
    size_t n;
    cin >> n;
    vector<size_t> A(n);
    size_t tot = 0;
    for (size_t i = 0; i < n; ++i)
    {
        cin >> A[i];
        tot += A[i];
    }

    node_t *root = new_node({0, 0, 0});
    vector<size_t> Psum(n + 1);

    Psum[0] = 0;
    size_t opt = tot;
    for (size_t i = 1; i < n + 1; ++i)
    {
        size_t x_i = Psum[i - 1] + A[i - 1];
        Psum[i] = x_i;
        size_t max_x = tot + 1;
        for (size_t j = i; j > 1; --j)
        {
            array<size_t, k> point = {Psum[j - 1], x_i - Psum[j - 1], x_i};
            node_t *res = three_sided_tange_max_helper(root, point, 0);
            size_t x = x_i + Psum[j - 1] - res->point[2];
            if (x < max_x)
            {
                root = insert(root, {{x, x_i - Psum[j - 1], x_i}});
                max_x = x;
            }
            if (i == n)
                minr(opt, (x_i - res->point[2])); // Psum[j-1] - res->point[2] + x_1 - Psum[j-1]
        }
    }

    // Print output
    cout << opt << endl;

    return 0;
}
