// @check-accepted: task

#include <iostream>
#include <vector>
using namespace std;
using ll = long long;
using LL = pair<long,long>;

int main() {
    int N;
    cin >> N;
    vector<ll> l(N, 0), p(N);
    for(int i = 0; i < N; ++i) cin >> l[i];

    p[0] = l[0];
    p[1] = p[0] + l[1];
    vector<vector<LL>> states(N);
    vector<int> pos(N, 0);
    states[1].push_back(LL(l[0], 0));

    for(int i = 2; i < N; ++i) {
        p[i] = p[i - 1] + l[i];

        states[i].push_back(LL(p[i - 1], 0));
        for(int j = 1; j < i; ++j) {
            while(pos[j] + 1 < states[j].size() && p[i - 1] - p[j - 1] >= states[j][pos[j] + 1].second) {
                pos[j]++;
            }
            LL new_state = LL(p[i - 1] - p[j - 1], states[j][pos[j]].first);
            while(states[i].back().second >= new_state.second) states[i].pop_back();
            states[i].push_back(new_state);
        }
    }

    for(int j = 1; j < N; ++j) {
        while(pos[j] + 1 < states[j].size() && p[N - 1] - p[j - 1] >= states[j][pos[j] + 1].second) {
            pos[j]++;
        }
    }

    ll ans = p[N - 1];
    for(int i = 1; i < N; ++i) {
        ans = min(ans, states[i][pos[i]].first + p[N - 1] - p[i - 1]);
    }

    cout << ans << "\n";

    return 0;
}
