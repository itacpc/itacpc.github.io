// @check-runtime-error: task

#include <iostream>
#include <vector>

using namespace std;

typedef unsigned long long int ull;

#define maxr(a, b) (a) = max((a), (b));
#define minr(a, b) (a) = min((a), (b));

int main(int argc, char const *argv[])
{

  // Read Input
  size_t n;
  cin >> n;
  vector<size_t> A(n);
  size_t tot = 0;
  for (size_t i = 0; i < n; ++i)
  {
    cin >> A[i];
    tot += A[i];
  }

  vector<tuple<size_t, size_t, size_t>> P(n + 1);
  vector<size_t> Psum(n + 1);

  P.push_back({0, 0, 0});
  Psum[0] = 0;
  for (size_t i = 1; i < n + 1; ++i)
  {
    size_t x_i = Psum[i - 1] + A[i - 1];
    Psum[i] = x_i;
    size_t max_y_i = x_i;
    for (size_t j = P.size(); j > 0; --j)
    {
      const auto& elem = P[j-1];
      if (get<1>(elem) <= (x_i - get<0>(elem)) && get<2>(elem) < max_y_i)
      {
        P.push_back({x_i, get<2>(elem), x_i - get<0>(elem)});
        max_y_i = get<2>(elem);
      }
    }
  }

  size_t res = tot;
  for (size_t j = P.size(); j > 0; --j)
  {
    const auto &elem = P[j - 1];
    if (get<0>(elem) == tot) 
      minr(res, (get<1>(elem) + get<2>(elem)));
  }

  // Print output
  cout << res << endl;

  return 0;
}
