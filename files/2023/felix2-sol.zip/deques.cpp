// @check-accepted: task

#include <iostream>
#include <vector>
#include <deque>

using namespace std;

typedef unsigned long long int ull;

#define maxr(a, b) (a) = max((a), (b));
#define minr(a, b) (a) = min((a), (b));

struct point_t{
  size_t x;
  size_t y;
};

int main(int argc, char const *argv[])
{

  // Read Input
  size_t n;
  cin >> n;
  vector<size_t> A(n);
  size_t tot = 0;
  for (size_t i = 0; i < n; ++i)
  {
    cin >> A[i];
    tot += A[i];
  }

  vector<size_t> Psum(n + 1);
  vector<deque<point_t>> deques(n+1);

  Psum[0] = 0;
  deques[0].push_back({0,0});
  size_t opt = tot;
  for (size_t i = 1; i < n + 1; ++i)
  {
    size_t x_i = Psum[i - 1] + A[i - 1];
    Psum[i] = x_i;
    for(size_t j = 0; j < i; ++j)
    {
      point_t best;
      bool visit = false;
      while(!deques[j].empty() && deques[j].front().x + Psum[j] < x_i)
      {
        best = deques[j].front();
        deques[j].pop_front();
        visit = true;
      }
      if(visit)
      {
        deques[j].push_front(best);
        while(!deques[i].empty() && deques[i].back().x > best.y) deques[i].pop_back();
        deques[i].push_back({best.y,x_i - Psum[j]});
        if (i == n)
          minr(opt, (best.y +  x_i - Psum[j]));
      }
    }
  }

  // Print output
  cout << opt << endl;

  return 0;
}
