// @check-accepted: task

#include <iostream>

using namespace std;

int main() {
    int N;

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin >> N;

    int res = 3000;

    for (int i = 0, d; i < N; i++) {
        cin >> d;
        res += d;
    }

    cout << res << endl;

    return 0;
}
