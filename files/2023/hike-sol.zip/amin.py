#!/usr/bin/env python3
# @check-accepted: task

n = int(input())
s = 3000
for i in map(int, input().split()):
	s += i
print(s)
