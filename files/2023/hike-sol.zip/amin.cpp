// @check-accepted: task

#include <iostream>

using namespace std;

int main()
{
	int n;
	cin >> n;

	int sum = 3000;
	for (int i = 0; i < n; i++)
	{
		int d;
		cin >> d;
		sum += d;
	}

	cout << sum << '\n';
	return 0;
}
