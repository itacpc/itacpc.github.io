// @check-accepted: task

#include <iostream>
#include <vector>
using namespace std;
using ll = long long;

int N, M;
ll add_cost, remove_cost;
vector<vector<int>> adjl;
vector<bool> visited;

void visit(int i, int &node_count, int &edge_count) {
    visited[i] = true;
    node_count++;
    edge_count += adjl[i].size();
    for(int j: adjl[i]) {
        if(!visited[j]) {
            visit(j, node_count, edge_count);
        }
    }
}

int main() {
    cin >> N >> M >> add_cost >> remove_cost;
    adjl.resize(N);
    visited.resize(N, false);
    for(int i = 0, u, v; i < M; ++i) {
        cin >> u >> v;
        --u; --v;
        adjl[u].push_back(v);
        adjl[v].push_back(u);
    }

    int cc = 0;
    int to_remove = 0;
    for(int i = 0; i < N; ++i) {
        if(!visited[i]) {
            int node_count = 0, edge_count = 0;
            visit(i, node_count, edge_count);
            edge_count /= 2;
            cc++;
            to_remove += edge_count - node_count + 1;
        }
    }

    cout << add_cost * (cc - 1) + remove_cost * (to_remove) << "\n";

    return 0;
}
