// @check-accepted: task

#include <iostream>
#include <vector>
using namespace std;
using ll = long long;

int N, M;
ll add_cost, remove_cost;
vector<vector<int>> adjl;
vector<bool> visited;

void visit(int i) {
    visited[i] = true;
    for(int j: adjl[i]) {
        if(!visited[j]) {
            visit(j);
        }
    }
}

int main() {
    cin >> N >> M >> add_cost >> remove_cost;
    adjl.resize(N);
    visited.resize(N, false);
    for(int i = 0, u, v; i < M; ++i) {
        cin >> u >> v;
        --u; --v;
        adjl[u].push_back(v);
        adjl[v].push_back(u);
    }

    int cc = 0;
    for(int i = 0; i < N; ++i) {
        if(!visited[i]) {
            visit(i);
            cc++;
        }
    }

    int to_add = cc - 1;
    int to_remove = M + to_add - (N - 1);

    cout << add_cost * to_add + remove_cost * to_remove << "\n";

    return 0;
}
