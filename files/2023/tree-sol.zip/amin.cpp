// @check-accepted: task

#include <iostream>
#include <vector>

using namespace std;

const int maxn = 1e6;
vector <int> adj[maxn];
bool mark[maxn];

void dfs(int v)
{
	mark[v] = true;
	for (int u : adj[v])
		if (!mark[u])
			dfs(u);
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);

	int n, m;
	cin >> n >> m;
	
	int cp, cn;
	cin >> cp >> cn;

	for (int i = 0; i < m; i++)
	{
		int u, v;
		cin >> u >> v;
		u--, v--;
		adj[v].push_back(u);
		adj[u].push_back(v);
	}

	int cmp = 0;
	for (int v = 0; v < n; v++)
		if (!mark[v])
		{
			cmp++;
			dfs(v);
		}

	cout << 1LL * (m - n + cmp) * cn + 1LL * (cmp - 1) * cp << '\n';

	return 0;
}
