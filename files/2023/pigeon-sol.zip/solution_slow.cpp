// @check-time-limit-exceeded: task

#include <iostream>
#include <vector>
using namespace std;
using ll = long long;

const ll MOD = 1e9 + 7;

struct point {
    int xl, xr, yl, yr;
};

int M, K;
vector<point> pts;
vector<ll> fact, invfact;

ll fastExp(ll b, ll e) {
    ll r = 1LL;
    while(e) {
        if(e & 1) r = (r * b) % MOD;
        b = (b * b) % MOD;
        e >>= 1;
    }
    return r;
}

ll binCoeff(int n, int k) {
    return fact[n] * invfact[k] % MOD * invfact[n - k] % MOD;
}

int valid(int x, int k) {
    if(x < -1) return -1;
    if(x > k) return k;
    return x;
}

int main() {
    cin >> M >> K;
    pts.resize(M);
    for(point &pt: pts) {
        int x, y, d, rx, ry;
        cin >> x >> y >> d;
        rx = x - y;
        ry = x + y;
        // use symmetry and always have 0 <= ry <= rx
        if(rx < 0) rx = -rx;
        if(ry < 0) ry = -ry;
        if(ry > rx) swap(rx, ry);
        pt.xl = rx - d;
        pt.xr = rx + d;
        pt.yl = ry - d;
        pt.yr = ry + d;
    }

    fact.resize(K + 1);
    invfact.resize(K + 1);
    fact[0] = invfact[0] = 1;
    for(int i = 1; i <= K; ++i) {
        fact[i] = (fact[i - 1] * i) % MOD;
        invfact[i] = fastExp(fact[i], MOD - 2);
    }

    for(int k = 0; k <= K; ++k) {
        ll ans = 0LL;
        vector<ll> p(k + 2);
        p[0] = 0LL;
        for(int i = 0; i <= k; ++i) {
            p[i + 1] = (p[i] + binCoeff(k, i)) % MOD;
        }
        for(point &pt: pts) {
            int il = valid((k + pt.xl + 1) / 2 - 1, k);
            int ir = valid((k + pt.xr) / 2, k);
            int jl = valid((k + pt.yl + 1) / 2 - 1, k);
            int jr = valid((k + pt.yr) / 2, k);

            ans += (p[ir + 1] - p[il + 1] + MOD) * (p[jr + 1] - p[jl + 1] + MOD) % MOD;
        }
        cout << (ans % MOD) << "\n";
    }
    
    return 0;
}
