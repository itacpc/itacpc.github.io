// @check-memory-limit-exceeded: task

#include <iostream>
#include <vector>
using namespace std;
using ll = long long;

const int MOD = 1e9 + 7;

struct point {
    int x, y, d;
};

int M, K;
vector<point> pts;
vector<vector<ll>> grid[2], cnt;

int dist(int xi, int yi, int xj, int yj) {
    return abs(xi - xj) + abs(yi - yj);
}

int main() {
    cin >> M >> K;
    pts.resize(M);
    for(point &pt: pts) cin >> pt.x >> pt.y >> pt.d;
    int offset = K + 5;
    grid[0].resize(2 * offset, vector<ll>(2 * offset, 0LL));
    grid[1].resize(2 * offset, vector<ll>(2 * offset, 0LL));
    cnt.resize(2 * offset, vector<ll>(2 * offset, 0LL));
    grid[0][offset][offset] = 1LL;

    for(int i = 0; i < 2 * offset; ++i) {
        for(int j = 0; j < 2 * offset; ++j) {
            for(point pt: pts) {
                if(dist(pt.x, pt.y, i - offset, j - offset) <= pt.d) {
                    ++cnt[i][j];
                }
            }
        }
    }

    for(int k = 0; k <= K; ++k) {
        ll ans = 0LL;
        for(int i = 0; i < 2 * offset; ++i) {
            for(int j = 0; j < 2 * offset; ++j) {
                ans += grid[k % 2][i][j] * cnt[i][j] % MOD;
            }
        }
        cout << (ans % MOD) << "\n";
        for(int i = offset - k - 1; i <= offset + k + 1; ++i) {
            for(int j = offset - k - 1; j <= offset + k + 1; ++j) {
                grid[(k + 1) % 2][i][j] = (grid[k % 2][i + 1][j] + grid[k % 2][i - 1][j] +
                                           grid[k % 2][i][j + 1] + grid[k % 2][i][j - 1]) % MOD;
            }
        }
    }

    return 0;
}
