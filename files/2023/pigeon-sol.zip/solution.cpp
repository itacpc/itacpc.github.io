// @check-accepted: task

#include <iostream>
#include <vector>
using namespace std;
using ll = long long;

const ll MOD = 1e9 + 7;

struct point {
    int xl, xr, yl, yr;
    int il = -1, ir = -1, jl = -1, jr = -1;
    ll pxl = 0LL, pxr = 0LL, pyl = 0LL, pyr = 0LL;
};

int M, K;
vector<point> pts;
vector<ll> fact, invfact;

ll fastExp(ll b, ll e) {
    ll r = 1LL;
    while(e) {
        if(e & 1) r = (r * b) % MOD;
        b = (b * b) % MOD;
        e >>= 1;
    }
    return r;
}

ll binCoeff(int n, int k) {
    return fact[n] * invfact[k] % MOD * invfact[n - k] % MOD;
}

bool valid(int x, int k) {
    return x >= 0 && x <= k;
}

int main() {
    cin >> M >> K;
    pts.resize(M);
    for(point &pt: pts) {
        int x, y, d, rx, ry;
        cin >> x >> y >> d;
        rx = x - y;
        ry = x + y;
        // use symmetry and always have 0 <= ry <= rx
        if(rx < 0) rx = -rx;
        if(ry < 0) ry = -ry;
        if(ry > rx) swap(rx, ry);
        pt.xl = rx - d;
        pt.xr = rx + d;
        pt.yl = ry - d;
        pt.yr = ry + d;
    }

    fact.resize(K + 1);
    invfact.resize(K + 1);
    fact[0] = invfact[0] = 1;
    for(int i = 1; i <= K; ++i) {
        fact[i] = (fact[i - 1] * i) % MOD;
        invfact[i] = fastExp(fact[i], MOD - 2);
    }

    for(int k = 0; k <= K; ++k) {
        ll ans = 0LL;
        for(point &pt: pts) {
            int il = min(k, (k + pt.xl + 1) / 2 - 1);
            int ir = min(k, (k + pt.xr) / 2);
            int jl = min(k, (k + pt.yl + 1) / 2 - 1);
            int jr = min(k, (k + pt.yr) / 2);

            while(pt.il + 1 <= il) pt.pxl = (pt.pxl + binCoeff(k, ++pt.il)) % MOD;
            while(pt.ir + 1 <= ir) pt.pxr = (pt.pxr + binCoeff(k, ++pt.ir)) % MOD;
            while(pt.jl + 1 <= jl) pt.pyl = (pt.pyl + binCoeff(k, ++pt.jl)) % MOD;
            while(pt.jr + 1 <= jr) pt.pyr = (pt.pyr + binCoeff(k, ++pt.jr)) % MOD;

            ans += (pt.pxr - pt.pxl + MOD) * (pt.pyr - pt.pyl + MOD) % MOD;

            if(valid(pt.il, k)) pt.pxl = (2 * pt.pxl - binCoeff(k, pt.il) + MOD) % MOD;
            if(valid(pt.ir, k)) pt.pxr = (2 * pt.pxr - binCoeff(k, pt.ir) + MOD) % MOD;
            if(valid(pt.jl, k)) pt.pyl = (2 * pt.pyl - binCoeff(k, pt.jl) + MOD) % MOD;
            if(valid(pt.jr, k)) pt.pyr = (2 * pt.pyr - binCoeff(k, pt.jr) + MOD) % MOD;
        }
        cout << (ans % MOD) << "\n";
    }
    
    return 0;
}
