// @check-accepted: task

#include <iostream>
#include <map> 

using namespace std;

int main() {
    cin.tie(0);
    cin.sync_with_stdio(0);
    
    int n;
    cin >> n;

    map<int, int> events;
    for (int i = 0; i < n; i++) {
        int x, y; cin >> x >> y;
        events[y] += x;
    }

    int ans = 0, curr = 0;

    for (auto e : events) {
        curr += e.second;
        ans = max(ans, curr);
    }
    cout << ans;
    
    return 0;
}
