// @check-accepted: task

#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>

using namespace std;

const int MAXY = 1e6;

int main() {
    cin.tie(0), cin.sync_with_stdio(0);

    int n; cin >> n;

    vector<int> count(MAXY + 5);

    for (int i = 0; i < n; i++) {
        int x, y;
        cin >> x >> y;
        count[y] += x;
    }

    partial_sum(count.begin(), count.end(), count.begin());
    cout << *max_element(count.begin(), count.end()) << endl;
    return 0;
}
