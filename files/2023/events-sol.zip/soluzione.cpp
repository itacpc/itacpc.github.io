// @check-accepted: task

#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>

using namespace std;

int main() {
    int N;

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin >> N;

    vector<pair<int, int>> T;

    for (int i = 0, x, y; i < N; i++) {
        cin >> x >> y;
        T.push_back({y, x});
    }

    sort(T.begin(), T.end());

    int maximum = 0;
    int counter = 0;

    for (auto el: T) {
        counter += el.second;
        maximum = (counter > maximum ? counter : maximum);
    }

    cout << maximum << endl;

    return 0;
}
