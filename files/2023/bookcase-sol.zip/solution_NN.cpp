// @check-time-limit-exceeded: task

#include <iostream>
#include <vector>

using namespace std;

bool checkPathDfs(const vector<vector<int>>& adj, int current, int target, vector<bool>& visited, vector<int>& path) {
    visited[current] = true;

    if (current == target) {
        path.push_back(current);
        return true;
    }

    for (int child : adj[current]) if (!visited[child]) {
        if (checkPathDfs(adj, child, target, visited, path)) {
            path.push_back(current);
            return true;
        }
    }

    return false;
}

bool isPal(string s, size_t len) {
    for (int l = 0, r = len-1; l <= len/2 && r >= len/2; l++, r--)
        if (s[l] != s[r])
            return false;

    return true;
}

int main() {
    int N;
    int M;
    int Q;

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin >> N >> M;

    char letters[N+1];
    vector<vector<int>> edges(N);

    for (int i = 0; i < N; i++)
        cin >> letters[i];

    for (int i = 0, from, to; i < M; i++) {
        cin >> from >> to;
        edges[from].push_back(to);
        edges[to].push_back(from);
    }

    cin >> Q;

    for (int q = 0, X, Y; q < Q; q++) {
        vector<int> path;
        string result = "";

        cin >> X >> Y;

        vector<bool> visited(N, false);
        checkPathDfs(edges, X, Y, visited, path);
            
        for (auto node : path)
            result += letters[node];

        if (isPal(result, result.length())) cout << "YES" << endl;
        else cout << "NO" << endl;
    }

    return 0;
}
