// @check-accepted: task

#include <iostream>
#include <vector>
using namespace std;
using ll = long long;
using LL = pair<ll,ll>;

LL operator+(const LL &x, const LL &y) {
    return LL(x.first + y.first, x.second + y.second);
}

LL operator*(const LL &x, const LL &y) {
    return LL(x.first * y.first, x.second * y.second);
}

LL operator%(const LL &x, const ll &m) {
    return LL(x.first % m, x.second % m);
}

const LL P = LL(31, 37);
const ll MOD = 1e9 + 7;

vector<LL> powP;

vector<char> c;
vector<vector<int>> adjl, ancestor;
vector<int> depth;
vector<vector<LL>> hashes_up, hashes_down;

void root(int u, int p = -1, int d = 0) {
    ancestor[u].push_back(p);
    ll hash = c[u] - 'a' + 1;
    hashes_up[u].push_back(LL(hash, hash));
    hashes_down[u].push_back(LL(hash, hash));
    depth[u] = d;
    for(int v: adjl[u]) {
        if(v == p) continue;
        root(v, u, d + 1);
    }
}

int lca(int u, int v) {
    if(depth[u] < depth[v]) swap(u, v);
    for(int k = ancestor[u].size() - 1; k >= 0; --k) {
        if(depth[u] - (1 << k) >= depth[v]) {
            u = ancestor[u][k];
        }
    }
    if (u == v) return u;
    for(int k = ancestor[v].size() - 1; k >= 0; --k) {
        if(ancestor[u][k] != -1 && ancestor[u][k] != ancestor[v][k]) {
            u = ancestor[u][k];
            v = ancestor[v][k];
        }
    }
    return ancestor[u][0];
}

LL get_hash(int u, int l, int v) {
    LL hash = LL(0, 0);
    int d = depth[u] + depth[v] - 2 * depth[l];

    int du = depth[u] - depth[l];
    for(int k = ancestor[u].size() - 1, p = 0; k >= 0; --k) {
        if((1 << k) <= du) {
            hash = (hash + hashes_up[u][k] * powP[p]) % MOD;
            p += (1 << k);
            du -= (1 << k);
            u = ancestor[u][k];
        }
    }

    int dv = depth[v] - depth[l] + 1;
    for(int k = ancestor[v].size() - 1, p = d + 1; k >= 0; --k) {
        if((1 << k) <= dv) {
            hash = (hash + hashes_down[v][k] * powP[p - (1 << k)])  % MOD;
            p -= (1 << k);
            dv -= (1 << k);
            v = ancestor[v][k];
        }
    }

    return hash;
}

int main() {
    int N, M;
    cin >> N >> M;
    c.resize(N);
    adjl.resize(N);
    ancestor.resize(N);
    depth.resize(N);
    hashes_up.resize(N);
    hashes_down.resize(N);
    for(int u = 0; u < N; ++u) cin >> c[u];
    for(int i = 0, u, v; i < M; ++i) {
        cin >> u >> v;
        adjl[u].push_back(v);
        adjl[v].push_back(u);
    }
    root(0);

    powP.resize(N + 1);
    powP[0] = LL(1, 1);
    for(int i = 1; i <= N; ++i) {
        powP[i] = (powP[i - 1] * P) % MOD;
    }

    for(int k = 1; (1 << k) <= N; ++k) {
        for(int u = 0; u < N; ++u) {
            int v = ancestor[u][k - 1];
            if(v != -1 && hashes_up[v].size() >= k) {
                ancestor[u].push_back(ancestor[v][k - 1]);
                hashes_up[u].push_back((hashes_up[u][k - 1] + hashes_up[v][k - 1] * powP[1 << (k - 1)]) % MOD);
                hashes_down[u].push_back((hashes_down[u][k -  1] * powP[1 << (k - 1)] + hashes_down[v][k - 1]) % MOD);
            } else {
                ancestor[u].push_back(-1);
            }
        }
    }

    int Q;
    cin >> Q;

    for(int q = 0, u, v; q < Q; ++q) {
        cin >> u >> v;
        int l = lca(u, v);
        if(get_hash(u, l, v) == get_hash(v, l, u)) cout << "YES\n";
        else cout << "NO\n";
    }
    return 0;
}
