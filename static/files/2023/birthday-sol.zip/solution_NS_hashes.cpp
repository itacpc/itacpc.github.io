// @check-accepted: task

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
using ll = long long;
using LL = pair<ll,ll>;

LL operator+(const LL &x, const LL &y) {
    return LL(x.first + y.first, x.second + y.second);
}

LL operator*(const LL &x, const LL &y) {
    return LL(x.first * y.first, x.second * y.second);
}

LL operator%(const LL &x, const ll &m) {
    return LL(x.first % m, x.second % m);
}

const int MAXS = 600;

const LL P = LL(31, 37);
const ll MOD = 1e9 + 7;

ll fast_exp(ll b, ll e) {
    ll r = 1;
    while(e) {
        if(e & 1) r = (r * b) % MOD;
        b = (b * b) % MOD;
        e >>= 1;
    }
    return r;
}

vector<LL> powP, invpowP;

const int SLOTS = 1e6 + 3;

vector<LL> forwardHashesCount[SLOTS], reverseHashesCount[SLOTS];

void insert(const LL &hash, bool forward) {
    if(forward) {
        forwardHashesCount[hash.first % SLOTS].push_back(hash);
    } else {
        reverseHashesCount[hash.first % SLOTS].push_back(hash);
    }
}

int find(const LL &hash, bool forward) {
    int res = 0;
    if(forward) {
        for(LL &other: forwardHashesCount[hash.first % SLOTS]) {
            if(hash == other) ++res;
        }
    } else {
        for(LL &other: reverseHashesCount[hash.first % SLOTS]) {
            if(hash == other) ++res;
        }
    }
    return res;
}

int main() {
    int N;
    cin >> N;
    vector<string> s(N);
    vector<vector<LL>> forwardHashes(N), reverseHashes(N);
    for(string &x: s) cin >> x;

    powP.resize(MAXS + 1);
    invpowP.resize(MAXS + 1);
    powP[0] = LL(1, 1);
    invpowP[MAXS] = LL(fast_exp(P.first, MOD - MAXS - 2), fast_exp(P.second, MOD - MAXS - 2));
    for(int i = 1; i <= MAXS; ++i) {
        powP[i] = powP[i - 1] * P % MOD;
        invpowP[MAXS - i] = invpowP[MAXS - i + 1] * P % MOD;
    }

    for(int i = 0; i < N; ++i) {
        LL forward_hash = LL(0, 0);
        LL reverse_hash = LL(0, 0);
        int n = s[i].size();
        forwardHashes[i].push_back(forward_hash);
        reverseHashes[i].push_back(reverse_hash);
        for(int c = 0; c < n; ++c) {
            ll forward_cur_hash = s[i][c] - 'a' + 1;
            ll reverse_cur_hash = s[i][n - c - 1] - 'a' + 1;
            forward_hash = (forward_hash + LL(forward_cur_hash, forward_cur_hash) * powP[c]) % MOD;
            reverse_hash = (reverse_hash + LL(reverse_cur_hash, reverse_cur_hash) * powP[c]) % MOD;
            forwardHashes[i].push_back(forward_hash);
            reverseHashes[i].push_back(reverse_hash);
        }
        insert(forwardHashes[i][n], true);
        insert(reverseHashes[i][n], false);

        reverseHashes[i].emplace_back();
        reverse(reverseHashes[i].begin(), reverseHashes[i].end());
    }

    ll ans = 0LL;

    for(int i = 0; i < N; ++i) {
        int n = s[i].size();
        LL reversePrefix = LL(0, 0);
        for(int c = 1; c <= n; ++c) {
            ll cur_hash = s[i][c - 1] - 'a' + 1;
            reversePrefix = (reversePrefix * P + LL(cur_hash, cur_hash)) % MOD;
            if(forwardHashes[i][c] == reversePrefix) {
                ans += find(reverseHashes[i][c + 1], true);
            }
        }

        LL forwardSuffix = LL(0, 0);
        for(int c = n; c >= 1; --c) {
            ll cur_hash = s[i][c - 1] - 'a' + 1;
            forwardSuffix = (forwardSuffix * P + LL(cur_hash, cur_hash)) % MOD;
            if(reverseHashes[i][c] == forwardSuffix) {
                ans += find(forwardHashes[i][c - 1], false);
            }
        }

        ans += find(forwardHashes[i][n], false);
        if(forwardHashes[i][n] == reverseHashes[i][1]) --ans;
    }

    cout << ans << "\n";

    return 0;
}
