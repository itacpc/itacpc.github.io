// @check-time-limit-exceeded: task

#include <iostream>
#include <string>
#include <vector>

using namespace std;

bool isPalindrome(string s, size_t len) {
    for (int l = 0, r = len-1; l <= len/2 && r >= len/2; l++, r--)
        if (s[l] != s[r])
            return false;

    return true;
}

int main() {
    uint N;
    uint cnt = 0;

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin >> N;

    vector<string> words(N);

    for (uint i = 0; i < N; i++)
        cin >> words[i];

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (i != j) {
                string concat = words[i] + words[j];
                if (isPalindrome(concat, concat.length()))
                    cnt++;
            }
        }
    }               

    cout << cnt << endl;

    return 0;
}
