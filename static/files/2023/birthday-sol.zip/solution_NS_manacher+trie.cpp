// @check-accepted: task

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
using namespace std;
using ll = long long;

const int MAXN = 10000;
const int MAXS = 600;

struct trie {
    struct node {
        int children[26];
        bool count = false;
    };

    node stock[MAXN * MAXS];
    int si = 0;
    int newnode() {
        return ++si;
    }

    int root;

    trie(): root(newnode()) {}

    void insert(const string &s) {
        node* n = &stock[root];
        for(char c: s) {
            int p = c - 'a';
            if(!n->children[p]) n->children[p] = newnode();
            n = &stock[n->children[p]];
        }
        n->count = true;
    }

    int search(const string &s, const vector<bool> &mask) {
        node* n = &stock[root];
        int res = 0;
        for(int i = 0; i < s.size(); ++i) {
            int p = s[i] - 'a';
            if(!n->children[p]) break;
            n = &stock[n->children[p]];
            if(mask[i]) res += n->count;
        }
        return res;
    }
};

vector<int> manacher(const string &s) {
    string t = "$#";
    for(char c: s) {
        t.push_back(c);
        t.push_back('#');
    }
    t.push_back('^');
    int n = t.size() - 2;

    vector<int> p(n + 2);
    int l = 1, r = 1;
    for(int i = 1; i <= n; i++) {
        p[i] = max(0, min(r - i, p[l + (r - i)]));
        while(t[i - p[i]] == t[i + p[i]]) {
            p[i]++;
        }
        if(i + p[i] > r) {
            l = i - p[i], r = i + p[i];
        }
    }
    return vector<int>(p.begin() + 1, p.end() - 1);
}

trie forward_trie, reverse_trie;

int main() {
    int N;
    cin >> N;
    vector<string> s(N);
    for(string &x: s) {
        cin >> x;
        forward_trie.insert(x);
        reverse(x.begin(), x.end());
        reverse_trie.insert(x);
        reverse(x.begin(), x.end());
    }

    ll ans = 0LL;

    for(string &x: s) {
        int n = x.size();
        vector<int> d = manacher(x);

        vector<bool> to_search(n, false);
        for(int i = 0, j = n + 1; i < n - 1; ++i, ++j) {
            if(d[j] / 2 == (n - i) / 2) {
                to_search[i] = true;
            }
        }
        ans += reverse_trie.search(x, to_search);

        to_search.assign(x.size(), false);
        for(int i = n - 1, j = n - 1; i >= 0; --i, --j) {
            if(d[j] / 2 == (i + 1) / 2) {
                to_search[i] = true;
            }
        }
        reverse(to_search.begin(), to_search.end());
        reverse(x.begin(), x.end());
        ans += forward_trie.search(x, to_search);

        if(d[n] / 2 == (n + 1) / 2) ans--;
    }

    cout << ans << "\n";

    return 0;
}
