// @check-accepted: task

#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm> 

using namespace std;

bool isPalindrome(string s, unordered_map<string, bool> &pm) {
    size_t len = s.length();

    if (pm.find(s) != pm.end())
        return pm[s];

    if (len == 0)
        return (pm[s] = true);

    for (int i = 0; i <= len/2; i++)
        if (s[i] != s[(len - i) - 1])
            return (pm[s] = false);

    return (pm[s] = true);
}

int main() {
    uint N;
    uint cnt = 0;

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin >> N;

    vector<string> words(N);
    unordered_map<string, int> wordsMap;
    unordered_map<string, bool> palindromeMap;

    for (uint i = 0; i < N; i++) {
        cin >> words[i];
        
        string rev = words[i];
        reverse(rev.begin(), rev.end());
        wordsMap.emplace(rev, i);
    }

    for (uint i = 0; i < N; i++) {
        size_t word_len = words[i].length();
        string r = words[i];
        string l = "";

        for (size_t j = 0; j < word_len; j++) {
            l.push_back(words[i][j]);
            r.erase(0, 1);

            if (wordsMap.find(l) != wordsMap.end() && isPalindrome(r, palindromeMap) && wordsMap[l] != i)
                cnt++;

            if (wordsMap.find(r) != wordsMap.end() && isPalindrome(l, palindromeMap) && wordsMap[r] != i)
                cnt++;
        }
    }

    cout << cnt << endl;

    return 0;
}
