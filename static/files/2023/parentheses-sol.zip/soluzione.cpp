// @check-accepted: task

#include <iostream>

using namespace std;

const int mod = 1e9 + 7;
const int N = 2e6 + 1;

int fact[N], rfact[N];

int power(int a, int b)
{
	if (b == 0)
		return 1;
	int res = power(a, b >> 1);
	res = (1LL * res * res) % mod;
	if (b & 1)
		res = (1LL * res * a) % mod;
	return res;
}

int nCr(int n, int r)
{
	if (r < 0 || r > n) 
		return 0;
	int res = (1LL * rfact[r] * rfact[n - r]) % mod;
	return (1LL * fact[n] * res) % mod;
}

int Get(int n, int k)
{
	return nCr(2 * n, n - k);
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	
	fact[0] = 1;
	for (int i = 1; i < N; i++) 
		fact[i] = (1LL * i * fact[i-1]) % mod;
	
	rfact[N-1] = power(fact[N - 1], mod - 2);
	for (int i = N - 1; i > 0; i--) 
		rfact[i - 1] = (1LL * i * rfact[i]) % mod;

	int T;
	cin >> T;
	while (T--)
	{
		int n, k;
		cin >> n >> k;
		
		int ans = (Get(n, 0) - Get(n, k + 1)) % mod;
		if (ans < 0) 
			ans += mod;

		cout << ans << "\n";
	}
	
	return 0;
}


