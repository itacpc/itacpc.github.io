// @check-accepted: task

#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdlib>

using namespace std;


using ll = long long;
ll LLINF = 1e18;

ll distance(pair<ll, ll> a, pair<ll, ll> b) {
    return llabs(a.first - b.first) + llabs(a.second - b.second);
}

// loop is just to cheat
ll distance_train(pair<ll, ll> a, pair<ll, ll> b, ll x, ll y) {
    // I hate this already :)
    ll cost = 0;
    while(true) {
        // train on left border, and then move clockwise
        if (a.first == 0) {
            // if b is on top of us
            if (b.first == 0 && b.second >= a.second) {
                return cost + b.second - a.second;
            }
            // we move to the top of the left border
            cost += y - a.second;
            a.second = y;
        }
        if (a.second == y) {
            // if b is on our right
            if (b.second == y && b.first >= a.first) {
                return cost + b.first - a.first;
            }
            // we move to the top right corner
            cost += x - a.first;
            a.first = x;
        }
        if (a.first == x) {
            // if b is below us
            if (b.first == x && b.second <= a.second) {
                return cost + a.second - b.second;
            }
            cost += a.second;
            a.second = 0;
        }
        if (a.second == 0) {
            // if b is on our left
            if (b.second == 0 && b.first <= a.first) {
                return cost + a.first - b.first;
            }
            cost += a.first;
            a.first = 0;
        }
    }
}

int main() {
    int t; cin >> t;
    while (t--) {
        ll x, y, tx, ty, wx, wy;
        cin >> x >> y >> tx >> ty >> wx >> wy;
        ll ans = LLINF;
        // William can reach only 4 points. For each of them, we compute the time it takes the train to get there the first time
        ll loop = (x+y)*2;

        vector<pair<ll, ll>> points = {{x, wy}, {0, wy}, {wx, y}, {wx, 0}};
        for (auto p : points) {
            ll first_arrival = distance_train({tx, ty}, p, x, y);
            if (first_arrival >= distance({wx, wy}, p))
                ans = min(ans, first_arrival);
            else
                ans = min(ans, first_arrival + loop);
        }
        cout << ans << "\n";
    }
}
