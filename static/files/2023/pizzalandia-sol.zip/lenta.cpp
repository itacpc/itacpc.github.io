// @check-time-limit-exceeded: task

#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdlib>

using namespace std;


using ll = long long;
ll LLINF = 1e18;

struct point {
    ll x, y;
    void add(const point& other) {
        x += other.x;
        y += other.y;
    }
    void box(point box) {
        x = max(0ll, x);
        y = max(0ll, y);
        x = min(box.x, x);
        y = min(box.y, y);
    }
    point get_d(point box) {
        point dir;
        if (x == 0) dir = {0, 1};
        if (y == box.y) dir = {1, 0};
        if (x == box.x) dir = {0, -1};
        if (y == 0 && x != 0) dir = {-1, 0};
        return dir;
    }
    bool operator != (point other) {
        return x != other.x || y != other.y;
    }
};


int main() {
    int t; cin >> t;
    while (t--) {
        ll x, y, tx, ty, wx, wy;
        cin >> x >> y >> tx >> ty >> wx >> wy;
        ll ans = LLINF;
        // simulate time for each direction
        vector<point> dirs = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};
        for (auto d : dirs) {
            point t = {tx, ty};
            point w = {wx, wy};
            ll time = 0;
            
            while (t != w) {
                time++;
                t.add(t.get_d({x, y}));
                w.add(d);
                w.box({x, y});
            }
            ans = min(ans, time);
        }
        cout << ans << "\n";
    }
}
