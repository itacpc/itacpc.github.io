// @check-accepted: task

#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;
using ii = pair<int,int>;

const int INF = 1e9;

vector<vector<int>> adj, cost, capacity;

void shortest_paths(int n, int v0, vector<int>& d, vector<int>& p) {
    d.assign(n, INF);
    d[v0] = 0;
    vector<bool> inq(n, false);
    queue<int> q;
    q.push(v0);
    p.assign(n, -1);

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        inq[u] = false;
        for (int v : adj[u]) {
            if (capacity[u][v] > 0 && d[v] > d[u] + cost[u][v]) {
                d[v] = d[u] + cost[u][v];
                p[v] = u;
                if (!inq[v]) {
                    inq[v] = true;
                    q.push(v);
                }
            }
        }
    }
}

int min_cost_flow(int N, int K, int s, int t) {
    int flow = 0;
    int cost = 0;
    vector<int> d, p;
    while (flow < K) {
        shortest_paths(N, s, d, p);
        if (d[t] == INF)
            break;

        int f = K - flow;
        int cur = t;
        while (cur != s) {
            f = min(f, capacity[p[cur]][cur]);
            cur = p[cur];
        }

        flow += f;
        cost += f * d[t];
        cur = t;
        while (cur != s) {
            capacity[p[cur]][cur] -= f;
            capacity[cur][p[cur]] += f;
            cur = p[cur];
        }
    }

    return cost;
}

void add_edge(int u, int v, int cst, int cap) {
    adj[u].push_back(v);
    adj[v].push_back(u);
    cost[u][v] = cst;
    cost[v][u] = -cst;
    capacity[u][v] = cap;
}

int main() {
    int N, T, K;
    cin >> N >> T >> K;
    vector<vector<int>> strings(N, vector<int>(T));
    vector<ii> d(N);
    for(int i = 0; i < N; ++i) {
        cin >> d[i].first;
        d[i].second = i;
        for(int &c: strings[i]) cin >> c;
    }
    sort(d.begin(), d.end());

    adj.assign(2 * N + 2, vector<int>());
    cost.assign(2 * N + 2, vector<int>(2 * N + 2, 0));
    capacity.assign(2 * N + 2, vector<int>(2 * N + 2, 0));

    vector<vector<bool>> adjm(N, vector<bool>(N, true));

    for(int u = 0, l = 0; u < N; ++u) {
        while(d[l].first + T <= d[u].first) ++l;

        int i = d[u].second;

        add_edge(N + u, u, -1, 1); // vertex capacity
        add_edge(2 * N, N + u, 0, 1); // from source
        add_edge(u, 2 * N + 1, 0, 1); // to sink

        for(int v = l; v < u; ++v) {
            int start_offset = d[u].first - d[v].first;
            int j = d[v].second;
            for(int c = 0; start_offset + c < T; ++c) {
                if(strings[j][start_offset + c] != strings[i][c]) {
                    adjm[v][u] = false;
                    break;
                }
            }
        }
    }

    for(int u = 0; u < N; ++u) {
        for(int v = u + 1; v < N; ++v) {
            if(adjm[u][v]) add_edge(u, N + v, 0, 1);
        }
    }

    cout << N + min_cost_flow(2 * N + 2, 2, 2 * N, 2 * N + 1) << "\n";

    return 0;
}
