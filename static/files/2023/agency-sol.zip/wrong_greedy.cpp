// @check-wrong-answer: task

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
using ii = pair<int,int>;

ii longest_path(int N, const vector<vector<bool>> &adjm, vector<int> &p) {
    vector<int> l(N, 1);
    p.assign(N, -1);
    ii max_path = ii(0, 0);

    for(int i = 0; i < N; ++i) {
        if(adjm[i][i]) continue; // blocked
        max_path = max(max_path, ii(l[i], i));
        for(int j = i + 1; j < N; ++j) {
            if(adjm[i][j] && l[i] + 1 > l[j]) {
                l[j] = l[i] + 1;
                p[j] = i;
            }
        }
    }

    return max_path;
}

int main() {
    int N, T, K;
    cin >> N >> T >> K;
    vector<vector<int>> strings(N, vector<int>(T));
    vector<ii> d(N);
    for(int i = 0; i < N; ++i) {
        cin >> d[i].first;
        d[i].second = i;
        for(int &c: strings[i]) cin >> c;
    }
    sort(d.begin(), d.end());

    vector<vector<bool>> adjm(N, vector<bool>(N, false));

    for(int u = 0; u < N; ++u) {
        for(int v = u + 1; v < N; ++v) {
            adjm[u][v] = true;
        }
    }

    for(int u = 0, l = 0; u < N; ++u) {
        while(d[l].first + T <= d[u].first) ++l;

        int i = d[u].second;

        for(int v = l; v < u; ++v) {
            int start_offset = d[u].first - d[v].first;
            int j = d[v].second;
            for(int c = 0; start_offset + c < T; ++c) {
                if(strings[j][start_offset + c] != strings[i][c]) {
                    adjm[v][u] = false;
                    break;
                }
            }
        }
    }

    vector<int> p(N);

    ii lpath1 = longest_path(N, adjm, p);

    int u = lpath1.second;
    while(u != -1) {
        adjm[u][u] = true; // mark blocked
        u = p[u];
    }

    ii lpath2 = longest_path(N, adjm, p);

    cout << N - lpath1.first - lpath2.first << "\n";

    return 0;
}
