// @check-accepted: task

#include <vector>
#include <iostream>
#include <queue>
#include <algorithm>

using namespace std;

// Min-Cost Max-Flow (UNIBOis booklet).

// change to another type if needed!
const int MAXCOST = 2e9 + 5;
const int MAXFLOW = 2e9 + 5;

// MAXN: number of maximum nodes
// T: type used to store flow
// X: type used to store costs
template <int MAXN, class T = int, class X = int>
struct MCMF {
  struct edge {
    int to, rev;
    T flow;
    X cost;
  };
  int s = MAXN - 2; // source
  int t = MAXN - 1; // sink
  vector<edge> g[MAXN];
  // f is flow/capacity, c is cost
  void add_edge(int a, int b, T f, X c, bool dir = 1) {
    g[a].push_back({b, int(g[b].size()), f, c});
    g[b].push_back({a, int(g[a].size()) - 1, dir ? 0 : f, -c});
  }
  X dist[MAXN];
  T flow[MAXN];
  queue<int> q;
  bool in_q[MAXN];
  int prev[MAXN]; // to retrace SPs
  edge* last[MAXN]; // link to edge
  bool spfa() {
    fill_n(dist, MAXN, MAXCOST);
    fill_n(flow, MAXN, MAXFLOW);
    fill_n(in_q, MAXN, 0);
    q.push(s); dist[s] = 0; in_q[s] = 1;
    prev[t] = -1;
    while(q.size()) {
      int curr = q.front();
      q.pop(); in_q[curr] = 0;
      for(auto &e : g[curr]) {
        if(e.flow > 0 && dist[curr] + e.cost < dist[e.to]) {
          dist[e.to] = dist[curr] + e.cost;
          prev[e.to] = curr;
          last[e.to] = &e;
          flow[e.to] = min(flow[curr], e.flow);
          if(!in_q[e.to]) {
            in_q[e.to] = 1, q.push(e.to);
          }
        }
      }
    }
    return prev[t] != -1;
  }
  // returns {flow, cost}
  pair<T, X> send_flow(int times = -1) {
    pair<T, X> ans;
    while(spfa()) {
      T pushed = flow[t];
      ans.first += pushed;
      ans.second += pushed * dist[t];
      int curr = t;
      while(curr != s) {
        edge &e = *last[curr];
        e.flow -= pushed;
        g[e.to][e.rev].flow += pushed;
        curr = prev[curr];
      }
    }
    return ans;
  }
};

const int MAX_N = 1000;
const int fake_sink = 2 * MAX_N;

int in(int i) {
    return i;
}

int out(int i) {
    return MAX_N + i;
}

int main() {
    cin.tie(0), cin.sync_with_stdio(0);

    int n, t, k;
    cin >> n >> t >> k;

    vector<pair<int, vector<int>>> plans(n);
    for (auto &plan : plans) {
        cin >> plan.first;
        plan.second.resize(t);
        for (int &i : plan.second) 
            cin >> i;
    }
    sort(plans.begin(), plans.end());

    MCMF<MAX_N * 2 + 3> mcmf;
    mcmf.add_edge(fake_sink, mcmf.t, 2, 0);

    for (int i = 0; i < n; i++) {
        mcmf.add_edge(mcmf.s, in(i), 1, 0);
        mcmf.add_edge(in(i), out(i), 1, -1);
        mcmf.add_edge(out(i), fake_sink, 1, 0);
        for (int j = i+1; j < n; j++) {
            int delta = plans[j].first - plans[i].first;
            // check for overlap
            bool ok = 1;
            for (int idx = 0; idx + delta < t; idx++) {
                if (plans[i].second[idx+delta] != plans[j].second[idx]) {
                    ok = 0;
                    break;
                }
            }
            if (ok) {
                mcmf.add_edge(out(i), in(j), 1, 0);
            }
        }
    }

    auto ans = mcmf.send_flow();
    cout << n + ans.second << endl;
}
